import React from "react";
import SignIn from "./SignIn.js";
import LoginWindow from "./App.js";
import ReactDOM from "react-dom";
import { BrowserRouter, Route } from "react-router-dom";


export default class App extends React.Component {
  render() {
    return (
      <BrowserRouter>
        <div className="App">
          <Route path="/" exact component={LoginWindow} />
          <Route path="/SignIn" exact component={SignIn} />
        </div>
      </BrowserRouter>
    );
  }
}

const rootElement = document.getElementById("root");
<Route> ReactDOM.render(<App />, rootElement) </Route>

