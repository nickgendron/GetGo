import "./styles.css";
import React from "react";
import { SignIn } from "./SignIn";
import { Link } from "react-router-dom";

//These are just buttons if we ever need them

/*function LoginButton() {
  return <button className="login">Login</button>;
}

function SignUpButton() {
  return (
    <button className="signup" onClick={SignIn}>
      Sign Up
    </button>
  );
}*/  

export default class LoginWindow extends React.Component {
  render() {
    return (
      <div>
        <h1>Home page</h1>
        <Link to="/SignIn">Sign In</Link>
      </div>
    );
  }
}



