import React, { useReducer, useState } from "react";
import { formReducer } from "./App";
import { Link } from "react-router-dom";

export function SignIn() {
  
  const formReducer = (state, event) => {
    return {
      ...state,
      [event.username]: event.value,
      [event.firstname]: event.value,
      [event.lastname]: event.value,
      [event.email]: event.value,
      [event.dob]: event.value,
      [event.password]: event.value
    };
  };
  const [formDatauser, setFormDatauser] = useReducer(formReducer, {});
  const [formDatafirst, setFormDatafirst] = useReducer(formReducer, {});
  const [formDatalast, setFormDatalast] = useReducer(formReducer, {});
  const [formDataemail, setFormDataemail] = useReducer(formReducer, {});
  const [formDatadob, setFormDatadob] = useReducer(formReducer, {});
  const [formDatapassword, setFormDatapassword] = useReducer(formReducer, {});
  const [submitting, setSubmitting] = useState(false);
  const handleSubmit = (event) => {
    event.preventDefault();
    setSubmitting(true);

    setTimeout(() => {
      setSubmitting(false);
    }, 3000);
  };

  const handleChangeuser = (event) => {
    setFormDatauser({
      username: event.target.username,
      value: event.target.value
    });
  };

  const handleChangefirst = (event) => {
    setFormDatafirst({
      firstname: event.target.firstname,
      value: event.target.value
    });
  };

  const handleChangelast = (event) => {
    setFormDatalast({
      lastname: event.target.lastname,
      value: event.target.value
    });
  };

  const handleChangeemail = (event) => {
    setFormDataemail({
      email: event.target.email,
      value: event.target.value
    });
  };

  const handleChangedob = (event) => {
    setFormDatadob({
      dob: event.target.dob,
      value: event.target.value
    });
  };

  const handleChangepassword = (event) => {
    setFormDatapassword({
      password: event.target.password,
      value: event.target.value
    });
  };

  return (
    <div className="wrapper">
      <h1>Sign Up</h1>
      {submitting}
      <form onSubmit={handleSubmit}>
        <fieldset>
          <label>
            <p>Username</p>
            <input username="username" onChange={handleChangeuser} />
            <p>First Name</p>
            <input firstname="firstname" onChange={handleChangefirst} />
            <p>Last Name</p>
            <input lastname="lastname" onChange={handleChangelast} />
            <p>Email</p>
            <input email="email" onChange={handleChangeemail} />
            <p>Date of Birth</p>
            <input dob="dob" onChange={handleChangedob} />
            <p>Password</p>
            <input password="password" onChange={handleChangepassword} />
          </label>
        </fieldset>
        <button type="submit">Submit</button>
      </form>
    </div>
  );
}

export default SignIn;