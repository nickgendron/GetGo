import React, { useReducer, useState } from "react";

export function SignIn() {
  const formReducer = (state, event) => {
    return {
      ...state,
      [event.username]: event.value,
      [event.firstname]: event.value,
      [event.lastname]: event.value,
      [event.email]: event.value,
      [event.dob]: event.value,
      [event.password]: event.value
    };
  };
  const [setFormDatauser] = useReducer(formReducer, {});
  const [setFormDatafirst] = useReducer(formReducer, {});
  const [setFormDatalast] = useReducer(formReducer, {});
  const [setFormDataemail] = useReducer(formReducer, {});
  const [setFormDatadob] = useReducer(formReducer, {});
  const [setFormDatapassword] = useReducer(formReducer, {});
  const [submitting, setSubmitting] = useState(false);
  const handleSubmit = (event) => {
    event.preventDefault();
    setSubmitting(true);

    setTimeout(() => {
      setSubmitting(false);
    }, 3000);
  };

  const handleChangeuser = (event) => {
    setFormDatauser({
      username: event.target.username,
      value: event.target.value
    });
  };

  const handleChangefirst = (event) => {
    setFormDatafirst({
      firstname: event.target.firstname,
      value: event.target.value
    });
  };

  const handleChangelast = (event) => {
    setFormDatalast({
      lastname: event.target.lastname,
      value: event.target.value
    });
  };

  const handleChangeemail = (event) => {
    setFormDataemail({
      email: event.target.email,
      value: event.target.value
    });
  };

  const handleChangedob = (event) => {
    setFormDatadob({
      dob: event.target.dob,
      value: event.target.value
    });
  };

  const handleChangepassword = (event) => {
    setFormDatapassword({
      password: event.target.password,
      value: event.target.value
    });
  };

  //username: variable to store username from a new user
  return (
    <div className="wrapper">
      <h1>Sign Up</h1>
      {submitting}
      <form onSubmit={handleSubmit}>
        <fieldset>
          <label>
            <p>Username</p>
            <input username="username" onChange={handleChangeuser} /> 
            <p>First Name</p>
            <input firstname="firstname" onChange={handleChangefirst} />
            <p>Last Name</p>
            <input lastname="lastname" onChange={handleChangelast} />
            <p>Email</p>
            <input email="email" onChange={handleChangeemail} />
            <p>Date of Birth</p>
            <input dob="dob" onChange={handleChangedob} />
            <p>Password</p>
            <input password="password" onChange={handleChangepassword} />
          </label>
        </fieldset>
        <button type="submit">Submit</button>
      </form>
    </div>
  );
}

export default SignIn;
