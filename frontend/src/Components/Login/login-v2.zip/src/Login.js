import React, { useReducer, useState } from "react";
import "./styles.css";

export function Login() {
  const formReducer = (state, event) => {
    return {
      ...state,
      [event.usernamePrev]: event.value,
      [event.passwordPrev]: event.value
    };
  };
  const [setFormDatauserPrev] = useReducer(formReducer, {});
  const [setFormDatapasswordPrev] = useReducer(formReducer, {});
  const [submitting, setSubmitting] = useState(false);
  const handleSubmit = (event) => {
    event.preventDefault();
    setSubmitting(true);

    setTimeout(() => {
      setSubmitting(false);
    }, 3000);
  };

  const handleChangeuserPrev = (event) => {
    setFormDatauserPrev({
      usernamePrev: event.target.username,
      value: event.target.value
    });
  };

  const handleChangepasswordPrev = (event) => {
    setFormDatapasswordPrev({
      passwordPrev: event.target.password,
      value: event.target.value
    });
  };

  return (
    <div className="wrapper">
      <h1>Log In</h1>
      {submitting}
      <form onSubmit={handleSubmit}>
        <fieldset>
          <label>
            <p>Username</p>
            <input
              usernamePrev="usernamePrev" //variable to store username from an already existing user
              onChange={handleChangeuserPrev}
            />
            <p>Password</p>
            <input
              passwordPrev="passwordPrev" //variable to store password from an already existing user
              onChange={handleChangepasswordPrev}
            />
          </label>
        </fieldset>
        <button type="submit">Submit</button>
      </form>
    </div>
  );
}

export default Login;
